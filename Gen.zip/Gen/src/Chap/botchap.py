import ctypes
import time

SendInput = ctypes.windll.user32.SendInput
 
PUL = ctypes.POINTER(ctypes.c_ulong)
class KeyBdInput(ctypes.Structure):
    _fields_ = [("wVk", ctypes.c_ushort),
                ("wScan", ctypes.c_ushort),
                ("dwFlags", ctypes.c_ulong),
                ("time", ctypes.c_ulong),
                ("dwExtraInfo", PUL)]

class HardwareInput(ctypes.Structure):
    _fields_ = [("uMsg", ctypes.c_ulong),
                ("wParamL", ctypes.c_short),
                ("wParamH", ctypes.c_ushort)]

class MouseInput(ctypes.Structure):
    _fields_ = [("dx", ctypes.c_long),
                ("dy", ctypes.c_long),
                ("mouseData", ctypes.c_ulong),
                ("dwFlags", ctypes.c_ulong),
                ("time",ctypes.c_ulong),
                ("dwExtraInfo", PUL)]

class Input_I(ctypes.Union):
    _fields_ = [("ki", KeyBdInput),
                 ("mi", MouseInput),
                 ("hi", HardwareInput)]

class Input(ctypes.Structure):
    _fields_ = [("type", ctypes.c_ulong),
                ("ii", Input_I)]


def PressKey(hexKeyCode):
    extra = ctypes.c_ulong(0)
    ii_ = Input_I()
    ii_.ki = KeyBdInput( 0, hexKeyCode, 0x0008, 0, ctypes.pointer(extra) )
    x = Input( ctypes.c_ulong(1), ii_ )
    ctypes.windll.user32.SendInput(1, ctypes.pointer(x), ctypes.sizeof(x))

def ReleaseKey(hexKeyCode):
    extra = ctypes.c_ulong(0)
    ii_ = Input_I()
    ii_.ki = KeyBdInput( 0, hexKeyCode, 0x0008 | 0x0002, 0, ctypes.pointer(extra) )
    x = Input( ctypes.c_ulong(1), ii_ )
    ctypes.windll.user32.SendInput(1, ctypes.pointer(x), ctypes.sizeof(x))

# directx scan codes http://www.gamespp.com/directx/directInputKeyboardScanCodes.html
time.sleep(6)
PressKey(0x11)
time.sleep(20.566712312698364)
ReleaseKey(0x11)
time.sleep(0.16899919509887695)
PressKey(0x1E)
time.sleep(10.694507122039795)
ReleaseKey(0x1E)
time.sleep(0.04799985885620117)
PressKey(0x11)
time.sleep(1.802865743637085)
ReleaseKey(0x11)
time.sleep(0.014999628067016602)
PressKey(0x1E)
time.sleep(3.3479995727539062)
ReleaseKey(0x1E)
time.sleep(0.016000986099243164)
PressKey(0x11)
time.sleep(0.57099947929382324)
ReleaseKey(0x11)
time.sleep(0.019999980926513672)
PressKey(0x12)
time.sleep(0.12199950218200684)
ReleaseKey(0x12)
PressKey(0x12)
time.sleep(0.12199950218200684)
ReleaseKey(0x12)
